var currentVersion = 6;

if(lastVersion && lastVersion > currentVersion){
	console.log(lastVersion, downUrl, updateLog, fileName)
	if (confirm("检测到有新版本，要下载吗？\n更新内容："+updateLog)) {
		fetch(downUrl)  
			.then(response => {  
				if (!response.ok) {  
					throw new Error('Network response was not ok');  
				}  
				return response.blob();  
			})  
			.then(blob => {  
				const url = URL.createObjectURL(blob);  
				const link = document.createElement('a');  
				link.href = url;  
				link.download = fileName;  
				link.click();   
				URL.revokeObjectURL(url);  
			})  
			.catch(error => console.error('Download failed:', error));  
	} else {  
		console.log("用户取消了下载");  
	}
}